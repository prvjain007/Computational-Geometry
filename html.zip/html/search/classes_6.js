var searchData=
[
  ['readwrite',['readWrite',['../classread_write.html',1,'']]]
];
