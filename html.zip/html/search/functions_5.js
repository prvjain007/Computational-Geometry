var searchData=
[
  ['jarvi',['jarvi',['../classjarvis.html#adfa3cd2051bd29e6a0c33e11b9ede4f0',1,'jarvis']]]
];
