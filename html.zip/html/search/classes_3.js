var searchData=
[
  ['jarvis',['jarvis',['../classjarvis.html',1,'']]]
];
