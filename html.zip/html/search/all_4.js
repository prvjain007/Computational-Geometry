var searchData=
[
  ['hull',['hull',['../classcompare.html#ab7253a7d1bac5f41ced194a3dda0ecec',1,'compare']]]
];
