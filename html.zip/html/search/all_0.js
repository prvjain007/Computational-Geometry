var searchData=
[
  ['andrew',['andrew',['../classnewt.html#a1abe2bf21f544ddea442d1d09a87a94b',1,'newt']]]
];
