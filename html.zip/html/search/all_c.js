var searchData=
[
  ['write',['write',['../classread_write.html#a3442724c2b24d29d3796f9ef1f5ac50c',1,'readWrite']]]
];
