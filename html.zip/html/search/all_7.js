var searchData=
[
  ['leftmost',['leftmost',['../classcompare.html#a3921dbe8a2210dcaecc019cbb25cd86b',1,'compare']]],
  ['lowest',['lowest',['../classcompare.html#ab568d8999522481fe078b6938f2d6384',1,'compare']]]
];
